import '@astrojs/internal-helpers/path';
import 'cookie';
import 'kleur/colors';
import 'string-width';
import './chunks/astro_8JUcFPqq.mjs';
import 'clsx';
import { compile } from 'path-to-regexp';

if (typeof process !== "undefined") {
  let proc = process;
  if ("argv" in proc && Array.isArray(proc.argv)) {
    if (proc.argv.includes("--verbose")) ; else if (proc.argv.includes("--silent")) ; else ;
  }
}

function getRouteGenerator(segments, addTrailingSlash) {
  const template = segments.map((segment) => {
    return "/" + segment.map((part) => {
      if (part.spread) {
        return `:${part.content.slice(3)}(.*)?`;
      } else if (part.dynamic) {
        return `:${part.content}`;
      } else {
        return part.content.normalize().replace(/\?/g, "%3F").replace(/#/g, "%23").replace(/%5B/g, "[").replace(/%5D/g, "]").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      }
    }).join("");
  }).join("");
  let trailing = "";
  if (addTrailingSlash === "always" && segments.length) {
    trailing = "/";
  }
  const toPath = compile(template + trailing);
  return toPath;
}

function deserializeRouteData(rawRouteData) {
  return {
    route: rawRouteData.route,
    type: rawRouteData.type,
    pattern: new RegExp(rawRouteData.pattern),
    params: rawRouteData.params,
    component: rawRouteData.component,
    generate: getRouteGenerator(rawRouteData.segments, rawRouteData._meta.trailingSlash),
    pathname: rawRouteData.pathname || void 0,
    segments: rawRouteData.segments,
    prerender: rawRouteData.prerender,
    redirect: rawRouteData.redirect,
    redirectRoute: rawRouteData.redirectRoute ? deserializeRouteData(rawRouteData.redirectRoute) : void 0,
    fallbackRoutes: rawRouteData.fallbackRoutes.map((fallback) => {
      return deserializeRouteData(fallback);
    })
  };
}

function deserializeManifest(serializedManifest) {
  const routes = [];
  for (const serializedRoute of serializedManifest.routes) {
    routes.push({
      ...serializedRoute,
      routeData: deserializeRouteData(serializedRoute.routeData)
    });
    const route = serializedRoute;
    route.routeData = deserializeRouteData(serializedRoute.routeData);
  }
  const assets = new Set(serializedManifest.assets);
  const componentMetadata = new Map(serializedManifest.componentMetadata);
  const clientDirectives = new Map(serializedManifest.clientDirectives);
  return {
    ...serializedManifest,
    assets,
    componentMetadata,
    clientDirectives,
    routes
  };
}

const manifest = deserializeManifest({"adapterName":"","routes":[{"file":"","links":[],"scripts":[],"styles":[{"type":"external","src":"/_astro/index.H0H340y5.css"}],"routeData":{"route":"/","type":"page","pattern":"^\\/$","segments":[],"params":[],"component":"src/pages/index.astro","pathname":"/","prerender":false,"fallbackRoutes":[],"_meta":{"trailingSlash":"ignore"}}}],"base":"/","trailingSlash":"ignore","compressHTML":true,"componentMetadata":[["/Users/matthewmiller/dev/mm-web-cv/src/pages/index.astro",{"propagation":"in-tree","containsHead":true}],["\u0000astro:content",{"propagation":"in-tree","containsHead":false}],["/Users/matthewmiller/dev/mm-web-cv/src/components/CvCareer.astro",{"propagation":"in-tree","containsHead":false}],["\u0000@astro-page:src/pages/index@_@astro",{"propagation":"in-tree","containsHead":false}],["/Users/matthewmiller/dev/mm-web-cv/src/components/CvCertifications.astro",{"propagation":"in-tree","containsHead":false}],["/Users/matthewmiller/dev/mm-web-cv/src/components/CvEducation.astro",{"propagation":"in-tree","containsHead":false}],["/Users/matthewmiller/dev/mm-web-cv/src/components/CvProjectWork.astro",{"propagation":"in-tree","containsHead":false}],["/Users/matthewmiller/dev/mm-web-cv/src/components/CvTechSkills.astro",{"propagation":"in-tree","containsHead":false}]],"renderers":[],"clientDirectives":[["idle","(()=>{var i=t=>{let e=async()=>{await(await t())()};\"requestIdleCallback\"in window?window.requestIdleCallback(e):setTimeout(e,200)};(self.Astro||(self.Astro={})).idle=i;window.dispatchEvent(new Event(\"astro:idle\"));})();"],["load","(()=>{var e=async t=>{await(await t())()};(self.Astro||(self.Astro={})).load=e;window.dispatchEvent(new Event(\"astro:load\"));})();"],["media","(()=>{var s=(i,t)=>{let a=async()=>{await(await i())()};if(t.value){let e=matchMedia(t.value);e.matches?a():e.addEventListener(\"change\",a,{once:!0})}};(self.Astro||(self.Astro={})).media=s;window.dispatchEvent(new Event(\"astro:media\"));})();"],["only","(()=>{var e=async t=>{await(await t())()};(self.Astro||(self.Astro={})).only=e;window.dispatchEvent(new Event(\"astro:only\"));})();"],["visible","(()=>{var r=(i,c,s)=>{let n=async()=>{await(await i())()},t=new IntersectionObserver(e=>{for(let o of e)if(o.isIntersecting){t.disconnect(),n();break}});for(let e of s.children)t.observe(e)};(self.Astro||(self.Astro={})).visible=r;window.dispatchEvent(new Event(\"astro:visible\"));})();"]],"entryModules":{"\u0000@astro-page:src/pages/index@_@astro":"pages/index.astro.mjs","\u0000@astro-renderers":"renderers.mjs","\u0000empty-middleware":"_empty-middleware.mjs","/src/pages/index.astro":"chunks/pages/index_2EK6L7H7.mjs","\u0000@astrojs-manifest":"manifest_izSCbmn_.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/1998-asgard.md?astroContentCollectionEntry=true":"chunks/1998-asgard_ibjiGzWb.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2003-ebooks.md?astroContentCollectionEntry=true":"chunks/2003-ebooks_0R3q0QST.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2004-bankwest.md?astroContentCollectionEntry=true":"chunks/2004-bankwest_MgK3drGc.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2005-elsevier.md?astroContentCollectionEntry=true":"chunks/2005-elsevier_BKZCjjiH.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2006-caplin.md?astroContentCollectionEntry=true":"chunks/2006-caplin_fiC5dPAH.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2007-aol.md?astroContentCollectionEntry=true":"chunks/2007-aol_1E-bZImT.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2008-synergy.md?astroContentCollectionEntry=true":"chunks/2008-synergy_E9DCk9jG.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2016-smartbeat.md?astroContentCollectionEntry=true":"chunks/2016-smartbeat_W9UuD5X3.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2017-onyx.md?astroContentCollectionEntry=true":"chunks/2017-onyx_UEUftSQy.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2018-mypass.md?astroContentCollectionEntry=true":"chunks/2018-mypass_YSWdS_Z3.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2022-dusty-dog.md?astroContentCollectionEntry=true":"chunks/2022-dusty-dog_l-dQ2Lye.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2022-gaia.md?astroContentCollectionEntry=true":"chunks/2022-gaia_TJsLBdky.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2022-powerledger.md?astroContentCollectionEntry=true":"chunks/2022-powerledger_jCS6gq7e.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2023-canceraid.md?astroContentCollectionEntry=true":"chunks/2023-canceraid_kpTOiJfG.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/education/1994-uwa.md?astroContentCollectionEntry=true":"chunks/1994-uwa_ki0wGQCv.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/projects/dusty.md?astroContentCollectionEntry=true":"chunks/dusty_UfsLZ2mN.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/projects/energy-trading.md?astroContentCollectionEntry=true":"chunks/energy-trading_7BYCa681.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/projects/mypass.md?astroContentCollectionEntry=true":"chunks/mypass_cHKrJLNQ.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/quals/2006-java.md?astroContentCollectionEntry=true":"chunks/2006-java_Hf7KqWN0.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/quals/2017-stanford.md?astroContentCollectionEntry=true":"chunks/2017-stanford_3rMcGCOd.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/quals/2022-linkedin-assessments.md?astroContentCollectionEntry=true":"chunks/2022-linkedin-assessments_XqCj6jVw.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/tech/database.json?astroDataCollectionEntry=true":"chunks/database_nSIxxYfp.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/tech/frontend.json?astroDataCollectionEntry=true":"chunks/frontend_kZKMPNCa.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/tech/query.json?astroDataCollectionEntry=true":"chunks/query_kg6eXyVQ.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/tech/server.json?astroDataCollectionEntry=true":"chunks/server_ioVkNq9T.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/1998-asgard.md?astroPropagatedAssets":"chunks/1998-asgard_CTX8FTBf.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2003-ebooks.md?astroPropagatedAssets":"chunks/2003-ebooks_MDb1a3V_.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2004-bankwest.md?astroPropagatedAssets":"chunks/2004-bankwest_g2WRkNbZ.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2005-elsevier.md?astroPropagatedAssets":"chunks/2005-elsevier_f96NuFvU.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2006-caplin.md?astroPropagatedAssets":"chunks/2006-caplin_BP6_YyW6.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2007-aol.md?astroPropagatedAssets":"chunks/2007-aol_-3mNjCqQ.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2008-synergy.md?astroPropagatedAssets":"chunks/2008-synergy_3h5URyx3.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2016-smartbeat.md?astroPropagatedAssets":"chunks/2016-smartbeat_k-y0F--F.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2017-onyx.md?astroPropagatedAssets":"chunks/2017-onyx_2Fz6Z07c.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2018-mypass.md?astroPropagatedAssets":"chunks/2018-mypass_mxRITi9C.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2022-dusty-dog.md?astroPropagatedAssets":"chunks/2022-dusty-dog_UkFU_xuT.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2022-gaia.md?astroPropagatedAssets":"chunks/2022-gaia_DlOaTnaw.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2022-powerledger.md?astroPropagatedAssets":"chunks/2022-powerledger_q0YxFL8Q.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2023-canceraid.md?astroPropagatedAssets":"chunks/2023-canceraid_dzwvT6uu.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/education/1994-uwa.md?astroPropagatedAssets":"chunks/1994-uwa_rU12UJsN.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/projects/dusty.md?astroPropagatedAssets":"chunks/dusty_4PtveM7u.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/projects/energy-trading.md?astroPropagatedAssets":"chunks/energy-trading_OaUKcz6h.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/projects/mypass.md?astroPropagatedAssets":"chunks/mypass_yEj7WKnS.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/quals/2006-java.md?astroPropagatedAssets":"chunks/2006-java_7W71K0P4.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/quals/2017-stanford.md?astroPropagatedAssets":"chunks/2017-stanford_su4umVKz.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/quals/2022-linkedin-assessments.md?astroPropagatedAssets":"chunks/2022-linkedin-assessments_1fJyfWpa.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/1998-asgard.md":"chunks/1998-asgard_ahpWlJI1.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2003-ebooks.md":"chunks/2003-ebooks_Js3AsChW.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2004-bankwest.md":"chunks/2004-bankwest_cdbbx2OK.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2005-elsevier.md":"chunks/2005-elsevier_KwFEMDsm.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2006-caplin.md":"chunks/2006-caplin_KPqOl_-s.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2007-aol.md":"chunks/2007-aol_LPs1oDrq.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2008-synergy.md":"chunks/2008-synergy_arPOCZwU.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2016-smartbeat.md":"chunks/2016-smartbeat_CXC4M9Kg.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2017-onyx.md":"chunks/2017-onyx_zFDKWexL.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2018-mypass.md":"chunks/2018-mypass_Yp95evbb.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2022-dusty-dog.md":"chunks/2022-dusty-dog_Cw_2uxEe.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2022-gaia.md":"chunks/2022-gaia_gK0IBVGD.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2022-powerledger.md":"chunks/2022-powerledger_wd1MK-p7.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/career/2023-canceraid.md":"chunks/2023-canceraid_A3ibAFcr.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/education/1994-uwa.md":"chunks/1994-uwa_3aW4ZoSQ.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/projects/dusty.md":"chunks/dusty_8qfexjZG.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/projects/energy-trading.md":"chunks/energy-trading_Kwj4kmwB.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/projects/mypass.md":"chunks/mypass_NPqbUbmk.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/quals/2006-java.md":"chunks/2006-java_NrWzy0Th.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/quals/2017-stanford.md":"chunks/2017-stanford_iB7lSe1r.mjs","/Users/matthewmiller/dev/mm-web-cv/src/content/quals/2022-linkedin-assessments.md":"chunks/2022-linkedin-assessments_qJGpxjw6.mjs","astro:scripts/before-hydration.js":""},"assets":[]});

export { manifest };
